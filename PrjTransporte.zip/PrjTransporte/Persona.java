public class Persona {

    public static final String CONDICION_REGULAR = "regular";
    public static final String CONDICION_ESTUDIANTE = "estudiante";
    public static final String CONDICION_CIUDADANO_ORO = "ciudadano de oro";

    private String nombre;
    private String condicion;

    public Persona(String pNombre, String pCondicion) {
        nombre = pNombre;
        if (esCondicionValida(pCondicion)) {
            condicion = pCondicion.toLowerCase();
        } else {
            condicion = CONDICION_REGULAR;
        }
    }

    public Persona(String pNombre) {
        this(pNombre, CONDICION_REGULAR);
    }

    public String getNombre() {
        return nombre;
    }

    public String getCondicion() {
        return condicion;
    }

    private boolean esCondicionValida(String pCondicion) {
        return CONDICION_REGULAR.equalsIgnoreCase(pCondicion)
            || CONDICION_ESTUDIANTE.equalsIgnoreCase(pCondicion)
            || CONDICION_CIUDADANO_ORO.equalsIgnoreCase(pCondicion);
    }

    public String toString() {
        return "Persona: " + nombre + " | Condicion: " + condicion;
    }
}