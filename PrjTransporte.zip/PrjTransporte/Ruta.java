import java.text.DecimalFormat;
import java.util.ArrayList;

public class Ruta {

    private static final int HORA_MINIMA = 0;
    private static final int HORA_MAXIMA = 23;
    private static final int MINUTO_MINIMO = 0;
    private static final int MINUTO_MAXIMO = 59;
    private static final int MINUTO_POR_OMISION = 0;
    private static final String SEPARADOR = ", ";
    private static final String SIMBOLO_MONEDA = "₡";
    private static final String FORMATO_MONTO = "#.##";

    private String codigo;
    private String nombre;
    private double tarifa;
    private ArrayList<Parada> misParadas;
    private ArrayList<HorarioSalida> misSalidas;

    public Ruta(String pCodigo, String pNombre, double pTarifa) {
        codigo = pCodigo;
        nombre = pNombre;
        tarifa = pTarifa;
        misParadas = new ArrayList<Parada>();
        misSalidas = new ArrayList<HorarioSalida>();
    }

    public void agregarParada(Parada pParada) {
        if (pParada != null && !existeParada(pParada)) {
            misParadas.add(pParada);
        }
    }

    public void registrarSalida(int pHora, int pMinuto) {
        if (esHorarioValido(pHora, pMinuto)) {
            misSalidas.add(new HorarioSalida(pHora, pMinuto));
        }
    }

    public void registrarSalida(int pHora) {
        registrarSalida(pHora, MINUTO_POR_OMISION);
    }

    public String consultarNombresParadas() {
        String msg = "";
        for (int i = 0; i < misParadas.size(); i++) {
            if (i > 0) {
                msg += SEPARADOR;
            }
            msg += misParadas.get(i).getNombre();
        }
        return msg;
    }

    public String consultarHorariosSalida() {
        String msg = "";
        for (int i = 0; i < misSalidas.size(); i++) {
            if (i > 0) {
                msg += SEPARADOR;
            }
            msg += misSalidas.get(i).toString();
        }
        return msg;
    }

    public String getNombre() {
        return nombre;
    }

    public double getTarifa() {
        return tarifa;
    }

    private boolean existeParada(Parada pParada) {
        for (Parada p : misParadas) {
            if (p.getCodigo().equals(pParada.getCodigo())) {
                return true;
            }
        }
        return false;
    }

    private boolean esHorarioValido(int pHora, int pMinuto) {
        return pHora >= HORA_MINIMA && pHora <= HORA_MAXIMA
            && pMinuto >= MINUTO_MINIMO && pMinuto <= MINUTO_MAXIMO;
    }

    public String toString() {
        String msg = "Ruta\n";
        msg += "  Codigo: " + codigo + "\n";
        msg += "  Nombre: " + nombre + "\n";
        msg += "  Tarifa: " + SIMBOLO_MONEDA + new DecimalFormat(FORMATO_MONTO).format(tarifa) + "\n";
        msg += "  Paradas: " + consultarNombresParadas() + "\n";
        msg += "  Horarios de salida registrados: " + misSalidas.size() + "\n";
        msg += "  Horarios: " + consultarHorariosSalida();
        return msg;
    }
}