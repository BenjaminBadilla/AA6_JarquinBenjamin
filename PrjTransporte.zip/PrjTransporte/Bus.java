import java.text.DecimalFormat;

public class Bus {

    public static final String PREFIJO_CODIGO = "BUS-";
    private static final double DESCUENTO_REGULAR = 0.0;
    private static final double DESCUENTO_ESTUDIANTE = 0.5;
    private static final double DESCUENTO_CIUDADANO_ORO = 1.0;
    private static final String TEXTO_SIN_RUTA = "(sin ruta asignada)";
    private static final String SIMBOLO_MONEDA = "₡";
    private static final String FORMATO_MONTO = "#.##";

    private static int cantidadBuses;

    private String codigo;
    private String placa;
    private int capacidad;
    private double totalRecaudado;
    private int cantidadPersonasAtendidas;
    private Ruta miRuta;

    public Bus(String pPlaca, int pCapacidad) {
        cantidadBuses++;
        codigo = PREFIJO_CODIGO + cantidadBuses;
        placa = pPlaca;
        capacidad = pCapacidad;
    }

    public void asignarRuta(Ruta pRuta) {
        if (pRuta != null) {
            miRuta = pRuta;
        }
    }

    public void cobrarPasaje(Persona pPersona) {
        if (miRuta != null && pPersona != null) {
            double tarifa = miRuta.getTarifa();
            double descuento = obtenerDescuento(pPersona.getCondicion());
            totalRecaudado += tarifa - (tarifa * descuento);
            cantidadPersonasAtendidas++;
        }
    }

    public String consultarNombreRuta() {
        if (miRuta == null) {
            return TEXTO_SIN_RUTA;
        }
        return miRuta.getNombre();
    }

    public String getCodigo() {
        return codigo;
    }

    public double getTotalRecaudado() {
        return totalRecaudado;
    }

    public int getCantidadPersonasAtendidas() {
        return cantidadPersonasAtendidas;
    }

    public static int getCantidadBuses() {
        return cantidadBuses;
    }

    private double obtenerDescuento(String pCondicion) {
        switch (pCondicion) {
            case Persona.CONDICION_ESTUDIANTE:
                return DESCUENTO_ESTUDIANTE;
            case Persona.CONDICION_CIUDADANO_ORO:
                return DESCUENTO_CIUDADANO_ORO;
            default:
                return DESCUENTO_REGULAR;
        }
    }

    public String toString() {
        String msg = "Bus\n";
        msg += "  Codigo: " + codigo + "\n";
        msg += "  Placa: " + placa + "\n";
        msg += "  Capacidad: " + capacidad + "\n";
        msg += "  Ruta asignada: " + consultarNombreRuta() + "\n";
        msg += "  Personas atendidas: " + cantidadPersonasAtendidas + "\n";
        msg += "  Total recaudado: " + SIMBOLO_MONEDA + new DecimalFormat(FORMATO_MONTO).format(totalRecaudado);
        return msg;
    }
}