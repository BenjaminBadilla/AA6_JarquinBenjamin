public class HorarioSalida {

    private static final String FORMATO_HORARIO = "%02d:%02d";

    private int hora;
    private int minuto;

    public HorarioSalida(int pHora, int pMinuto) {
        hora = pHora;
        minuto = pMinuto;
    }

    public String toString() {
        return String.format(FORMATO_HORARIO, hora, minuto);
    }
}