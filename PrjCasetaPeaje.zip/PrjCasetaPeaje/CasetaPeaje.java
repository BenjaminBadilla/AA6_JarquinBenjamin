public class CasetaPeaje {

    private int numeroCaseta;
    private String nombreAutopista;
    private double totalCobrado;

    private static int cantidadCasetas;

    private static final String TIPO_PARTICULAR = "particular";
    private static final String TIPO_CARGA_LIVIANA = "carga liviana";
    private static final String TIPO_CARGA = "carga";
    private static final String TIPO_MOTO = "moto";

    private static final double MONTO_PARTICULAR = 100;
    private static final double MONTO_CARGA_LIVIANA = 200;
    private static final double MONTO_CARGA = 500;
    private static final double MONTO_MOTO = 75;
    private static final double MONTO_TIPO_DESCONOCIDO = 0;

    public CasetaPeaje(String pNombreAutopista) {
        cantidadCasetas++;
        numeroCaseta = cantidadCasetas;
        nombreAutopista = pNombreAutopista;
    }

    public void cobrarPeaje(Vehiculo obj) {
        totalCobrado += obtenerMonto(obj.getTipo());
    }

    private double obtenerMonto(String pTipo) {
        switch (pTipo.toLowerCase()) {
            case TIPO_PARTICULAR:
                return MONTO_PARTICULAR;
            case TIPO_CARGA_LIVIANA:
                return MONTO_CARGA_LIVIANA;
            case TIPO_CARGA:
                return MONTO_CARGA;
            case TIPO_MOTO:
                return MONTO_MOTO;
            default:
                return MONTO_TIPO_DESCONOCIDO;
        }
    }

    public double getTotalCobrado() {
        return totalCobrado;
    }

    public static int getCantidadDeCasetasPeaje() {
        return cantidadCasetas;
    }

    public String toString() {
        return "Caseta de Peaje número: " + numeroCaseta + "\n" +
               "Autopista= " + nombreAutopista + "\n" +
               "Total Cobrado= " + totalCobrado + "\n";
    }
}